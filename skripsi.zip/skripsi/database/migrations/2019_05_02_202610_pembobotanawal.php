<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Pembobotanawal extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Pembobotanawals', function (Blueprint $table) {
            $table->increments('id_pembobotanawal');
       
            $table->string('kriteria_1a');
            $table->string('kriteria_1b');
            $table->string('kriteria_1c');
            $table->string('kriteria_2a');
            $table->string('kriteria_2b');
            $table->string('kriteria_3a');
            $table->string('kriteria_3b');
            $table->string('kriteria_4a');
            $table->string('kriteria_4b');
            $table->string('kriteria_4c');
            $table->string('kriteria_4d');
            $table->string('kriteria_4e');
            $table->string('kriteria_5a');
            $table->string('kriteria_5b');
            $table->string('kriteria_6a');
            $table->string('kriteria_6b');
            $table->string('kriteria_6c');
             $table->string('kriteria_7a');
            $table->string('kriteria_7b');
           



           
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
