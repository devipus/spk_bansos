<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pembobotanawal extends Model
{
    Protected $primaryKey ='id_pembobotanawal';
   Protected $fillable=['id_pembobotanawal','kriteria_1a','kriteria_1b','kriteria_1c','kriteria_2a','kriteria_2b','kriteria_3a','kriteria_3b','kriteria_4a','kriteria_4b','kriteria_4c','kriteria_4d','kriteria_4e','kriteria_5a','kriteria_5b','kriteria_6a','kriteria_6b','kriteria_6c','kriteria_7a','kriteria_7b'];
}
