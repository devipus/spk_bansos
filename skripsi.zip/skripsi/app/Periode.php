<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Periode extends Model
{
    Protected $primaryKey ='id_periode';
   Protected $fillable=['id_periode','periode'];
}
