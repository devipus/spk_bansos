<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class jabatan extends Model
{
    Protected $primaryKey ='id_jabatan';
   Protected $fillable=['id_jabatan','jabatan'];
}
