<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Districts extends Model
{
  Protected $primaryKey ='id';
   Protected $fillable=['id','country','region','city','code','name','latitude','longitude'];
    public function __construct(){
   	$this->setTable('geo_districts');
   	return parent::__construct();

   }
   public function countrys(){
   		 return $this -> hasOne (Countries::class, 'iso', 'country');

   }
   public function regions(){
   		 return $this -> hasOne (Regions::class, 'code', 'region');
   }
   public function cities(){
   		 return $this -> hasOne (Cities::class, 'code', 'city');
   }
   public function villages(){
   		 return $this -> hasOne (Villages::class, 'district', 'code');
   }
}
