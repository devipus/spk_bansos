<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Regions extends Model
{
	  
    Protected $primaryKey ='id';
   Protected $fillable=['id','country','code','name','latitude','longitude'];

   public function __construct(){
   	$this->setTable('geo_regions');
   	return parent::__construct();

   }
   public function countrys(){
   		 return $this -> hasOne (Countries::class, 'iso', 'country');

   }
   public function cities(){
   		 return $this -> hasOne (Cities::class, 'region', 'code');
   }
   public function districts(){
   		 return $this -> hasOne (Districts::class, 'region', 'code');
   }
   public function villages(){
   		 return $this -> hasOne (Villages::class, 'region', 'code');
   }
}
