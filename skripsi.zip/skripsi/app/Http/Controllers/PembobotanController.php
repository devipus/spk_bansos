<?php
/**['id_Pembobotan', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Pembobotan', 'ket_dos', 'rutinitas'];*/

namespace App\Http\Controllers;

use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;

use App\Pembobotan;
use App\Dataumum;
use App\Provinsi;
use App\Kabkota;
use App\Kec;
use App\Kel;

use Validator;
use routes;
use App\Http\Requests\PembobotanRequest;
use Illuminate\Support\Facades\DB;


class PembobotanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
           return view('pembobotan');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PembobotanRequest $request)
    
        /**['id_Pembobotan', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Pembobotan', 'ket_dos', 'rutinitas'];*/
      {

        if(!$request->ajax()){ abort('403'); }

        $dataUmum = new Pembobotan();
        $dataUmum->rt = $request->get('rt');
        $dataUmum->kriteria_1a = $request->get('kriteria_1a');
        $dataUmum->kriteria_1b = $request->get('kriteria_1b');
        $dataUmum->kriteria_1c = $request->get('kriteria_1c');
        $dataUmum->kriteria_2a = $request->get('kriteria_2a');
        $dataUmum->kriteria_2b = $request->get('kriteria_2b');
        $dataUmum->kriteria_3a = $request->get('kriteria_3a');
        $dataUmum->kriteria_3b = $request->get('kriteria_3b');
        $dataUmum->kriteria_4a = $request->get('kriteria_4a');
        $dataUmum->kriteria_4b = $request->get('kriteria_4b');
        $dataUmum->kriteria_4c = $request->get('kriteria_4c');
        $dataUmum->kriteria_4d = $request->get('kriteria_4d');
        $dataUmum->kriteria_4e = $request->get('kriteria_4e');
        $dataUmum->kriteria_5a = $request->get('kriteria_5a');
        $dataUmum->kriteria_5b = $request->get('kriteria_5b');
        $dataUmum->kriteria_6a = $request->get('kriteria_6a');
        $dataUmum->kriteria_6b = $request->get('kriteria_6b');
        $dataUmum->kriteria_6c = $request->get('kriteria_6c');
        $dataUmum->kriteria_7a = $request->get('kriteria_7a');
        $dataUmum->kriteria_7b = $request->get('kriteria_7b');

        $ret = true;
        if(!$dataUmum->save()){
            $ret = false;
        }

        return response()->json(['data' => $ret]);
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $pembobotan = Pembobotan::with('dataumum')->with(['dataumum.regions' => function($query){
        $query->where('country', 'ID');
     },'dataumum.cities' => function($query){
        $query->where('country', 'ID');
     },'dataumum.districts' => function($query){
        $query->where('country', 'ID');
     },'dataumum.villages' => function($query){
        $query->where('country', 'ID');
     }
     ])->where('id_Pembobotan', $id)->first();
        return $pembobotan;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    

        $Pembobotan = Pembobotan::find($id);
            $Pembobotan->rt =$request['rt'];
            $Pembobotan->periode =$request['periode'];
            $Pembobotan->kriteria_1a =$request['kriteria_1a'];
            $Pembobotan->kriteria_1b =$request['kriteria_1b'];
            $Pembobotan->kriteria_1c =$request['kriteria_1c'];
            $Pembobotan->kriteria_2a =$request['kriteria_2a'];
            $Pembobotan->kriteria_2b =$request['kriteria_2b'];
            $Pembobotan->kriteria_3a =$request['kriteria_3a'];
            $Pembobotan->kriteria_3b =$request['kriteria_3b'];
            $Pembobotan->kriteria_4a =$request['kriteria_4a'];
            $Pembobotan->kriteria_4b =$request['kriteria_4b'];
            $Pembobotan->kriteria_4c =$request['kriteria_4c'];
            $Pembobotan->kriteria_4d =$request['kriteria_4d'];
            $Pembobotan->kriteria_4e =$request['kriteria_4e'];
            $Pembobotan->kriteria_5a =$request['kriteria_5a'];
            $Pembobotan->kriteria_5b =$request['kriteria_5b'];
            $Pembobotan->kriteria_6a =$request['kriteria_6a'];
            $Pembobotan->kriteria_6b =$request['kriteria_6b'];
            $Pembobotan->kriteria_6c =$request['kriteria_6c'];
            $Pembobotan->kriteria_7a =$request['kriteria_7a'];
            $Pembobotan->kriteria_7b =$request['kriteria_7b'];
           
          
        $Pembobotan->update();
        return $Pembobotan;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
   {
    if($PembobotanDel = Pembobotan::destroy($id)){
            return ['success' =>  1];
        }else{
            return ['tidak success' =>  0];
        }
    }
     public function  apiPembobotan()
    {

//$user=\Auth::user();
          // $Pembobotan = Pembobotan::find($user->id);

     $Pembobotan = Pembobotan::with('dataumum')->with(['dataumum.regions' => function($query){
        $query->where('country', 'ID');
     },'dataumum.cities' => function($query){
        $query->where('country', 'ID');
     },'dataumum.districts' => function($query){
        $query->where('country', 'ID');
     },'dataumum.villages' => function($query){
        $query->where('country', 'ID');
     }
     ])->get();
       //$Pembobotan= siswa::where('id','=',$id)->first();
  // $Pembobotan = Pembobotan::where('user_id','=',\Auth::user()->id)->with('kegiatan')->get();
      ///  $Pembobotan = Pembobotan::select('tanggal',DB::raw("(SUM(ns_siang)) as ns_siang"),DB::raw("(SUM(tkno_siang)) as tkno_siang"),DB::raw("(SUM(tamu_siang)) as tamu_siang"),DB::raw("(SUM(ss_malam)) as ss_malam"),DB::raw("(SUM(ns_malam)) as ns_malam"))->groupBy('tanggal')->get(); //pertanggal,
        return DataTables::of($Pembobotan)
            ->addColumn('action', function($Pembobotan) {
                return  
                        '<a onclick="editForm('. $Pembobotan->id_pembobotan .')" class=btn btn-primary btn-xs"> <i class="glyphicon glyphicon-edit"> </i> Edit </a>' .
                        
                        '<a onclick="deleteData('. $Pembobotan->id_pembobotan .')" class=btn btn-danger btn-xs"> <i class="glyphicon glyphicon-trash"> </i> Delete </a>' ;

            })->make(true);
    }

    
}
