<?php
/**['id_Pembobotan', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Pembobotan', 'ket_dos', 'rutinitas'];*/

namespace App\Http\Controllers;

use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;

use App\Pembobotan;
use App\Dataumum;
use App\Regions;
use App\Cities;
use App\Districts;
use App\Countries;
use App\Villages;
use Validator;
use routes;
use App\Http\Requests\PembobotanRequest;
use Illuminate\Support\Facades\DB;


class PerangkinganController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->get('id_provinsi')&&$request->get('id_kabkota')&&$request->get('id_kec')&&$request->get('id_kel')){

         $queryregion=Regions::where('code', $request['id_provinsi'])
                                  ->where('country', 'ID')
                                  ->first();
                   
                 
                    $querycity=Cities::where('code', $request['id_kabkota'])
                                 ->where('country', 'ID')
                                 ->where('region', $request['id_provinsi'])
                                 ->first();
                   
              
                    $querydistrict=Districts::where('code', $request['id_kec'])
                                    ->where('country', 'ID')
                                    ->where('region', $request['id_provinsi'])
                                    ->where('city', $request['id_kabkota'])
                                    ->first();
                    
                    $queryvillage=Villages::where('code', $request['id_kel'])
                                   ->where('country', 'ID')
                                   ->where('region', $request['id_provinsi'])
                                   ->where('city', $request['id_kabkota'])
                                   ->where('district', $request['id_kec'])
                                   ->first();
                    if ($queryregion&&$querycity&&$querydistrict&&$queryvillage){
                        $querydataumum = Dataumum::where('id_provinsi', $request['id_provinsi'])->where('id_kabkota', $request['id_kabkota'])->where('id_kec', $request['id_kec'])->where('id_kel', $request['id_kel'])->get();

                            if($querydataumum){
                                // return redirect()->route('perangkingan.rank',['p'=>$request['id_provinsi'], 'c'=>$request['id_kabkota'], 'd'=>$request['id_kec'], 'k'=>$request['id_kel']]);

                             return view('perangkinganawal');
                            }

                    }
                   }

           return view('perangkingan');
        
  }

   

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PembobotanRequest $request)
    
        /**['id_Pembobotan', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Pembobotan', 'ket_dos', 'rutinitas'];*/
      {

        if(!$request->ajax()){ abort('403'); }

        $dataUmum = new Pembobotan();
        $dataUmum->rt = $request->get('rt');
        $dataUmum->kriteria_1a = $request->get('kriteria_1a');
        $dataUmum->kriteria_1b = $request->get('kriteria_1b');
        $dataUmum->kriteria_1c = $request->get('kriteria_1c');
        $dataUmum->kriteria_2a = $request->get('kriteria_2a');
        $dataUmum->kriteria_2b = $request->get('kriteria_2b');
        $dataUmum->kriteria_3a = $request->get('kriteria_3a');
        $dataUmum->kriteria_3b = $request->get('kriteria_3b');
        $dataUmum->kriteria_4a = $request->get('kriteria_4a');
        $dataUmum->kriteria_4b = $request->get('kriteria_4b');
        $dataUmum->kriteria_4c = $request->get('kriteria_4c');
        $dataUmum->kriteria_4d = $request->get('kriteria_4d');
        $dataUmum->kriteria_4e = $request->get('kriteria_4e');
        $dataUmum->kriteria_5a = $request->get('kriteria_5a');
        $dataUmum->kriteria_5b = $request->get('kriteria_5b');
        $dataUmum->kriteria_6a = $request->get('kriteria_6a');
        $dataUmum->kriteria_6b = $request->get('kriteria_6b');
        $dataUmum->kriteria_6c = $request->get('kriteria_6c');
        $dataUmum->kriteria_7a = $request->get('kriteria_7a');
        $dataUmum->kriteria_7b = $request->get('kriteria_7b');

        $ret = true;
        if(!$dataUmum->save()){
            $ret = false;
        }

        return response()->json(['data' => $ret]);
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
     public function  apiPembobotan()
    {

//$user=\Auth::user();
          // $Pembobotan = Pembobotan::find($user->id);

     $Pembobotan = Pembobotan::with('dataumum')->with(['dataumum.regions' => function($query){
        $query->where('country', 'ID');
     },'dataumum.cities' => function($query){
        $query->where('country', 'ID');
     },'dataumum.districts' => function($query){
        $query->where('country', 'ID');
     },'dataumum.villages' => function($query){
        $query->where('country', 'ID');
     }
     ])->get();
       //$Pembobotan= siswa::where('id','=',$id)->first();
  // $Pembobotan = Pembobotan::where('user_id','=',\Auth::user()->id)->with('kegiatan')->get();
      ///  $Pembobotan = Pembobotan::select('tanggal',DB::raw("(SUM(ns_siang)) as ns_siang"),DB::raw("(SUM(tkno_siang)) as tkno_siang"),DB::raw("(SUM(tamu_siang)) as tamu_siang"),DB::raw("(SUM(ss_malam)) as ss_malam"),DB::raw("(SUM(ns_malam)) as ns_malam"))->groupBy('tanggal')->get(); //pertanggal,
        return DataTables::of($Pembobotan)
            ->addColumn('action', function($Pembobotan) {
                return  
                        '<a onclick="editForm('. $Pembobotan->id_pembobotan .')" class=btn btn-primary btn-xs"> <i class="glyphicon glyphicon-edit"> </i> Edit </a>' .
                        
                        '<a onclick="deleteData('. $Pembobotan->id_pembobotan .')" class=btn btn-danger btn-xs"> <i class="glyphicon glyphicon-trash"> </i> Delete </a>' ;

            })->make(true);
    }

     public function rank(Request $request){

           return view('perangkingan')->with();
     }
    
}
