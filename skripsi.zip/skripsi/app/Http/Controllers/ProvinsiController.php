<?php
/**['id_Provinsi', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Provinsi', 'ket_dos', 'rutinitas'];*/

namespace App\Http\Controllers;

use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;

use App\Provinsi;

use Validator;
use routes;
use App\Http\Requests\ProvinsiRequest;
use Illuminate\Support\Facades\DB;


class ProvinsiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
           return view('provinsi');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProvinsiRequest $request)
    
        /**['id_Provinsi', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Provinsi', 'ket_dos', 'rutinitas'];*/
      {
        
        $data = [
        'provinsi' => $request['provinsi'],
       
   
        ];

       return Provinsi::create($data);
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $Provinsi = Provinsi::find($id);
        return $Provinsi;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $Provinsi = Provinsi::find($id);
            $Provinsi->provinsi =$request['provinsi'];
          
        $Provinsi->update();
        return $Provinsi;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
   {
    if($ProvinsiDel = Provinsi::destroy($id)){
            return ['success' =>  1];
        }else{
            return ['tidak success' =>  0];
        }
    }
     public function  apiProvinsi()
    {

//$user=\Auth::user();
          // $Provinsi = Provinsi::find($user->id);

     $Provinsi = Provinsi::all();
       //$Provinsi= siswa::where('id','=',$id)->first();
  // $Provinsi = Provinsi::where('user_id','=',\Auth::user()->id)->with('kegiatan')->get();
      ///  $Provinsi = Provinsi::select('tanggal',DB::raw("(SUM(ns_siang)) as ns_siang"),DB::raw("(SUM(tkno_siang)) as tkno_siang"),DB::raw("(SUM(tamu_siang)) as tamu_siang"),DB::raw("(SUM(ss_malam)) as ss_malam"),DB::raw("(SUM(ns_malam)) as ns_malam"))->groupBy('tanggal')->get(); //pertanggal,
        return DataTables::of($Provinsi)
            ->addColumn('action', function($Provinsi) {
                return  
                        '<a onclick="editForm('. $Provinsi->id_provinsi .')" class=btn btn-primary btn-xs"> <i class="glyphicon glyphicon-edit"> </i> Edit </a>' .
                        
                        '<a onclick="deleteData('. $Provinsi->id_provinsi .')" class=btn btn-danger btn-xs"> <i class="glyphicon glyphicon-trash"> </i> Delete </a>' ;

            })->make(true);
    }

    
}
