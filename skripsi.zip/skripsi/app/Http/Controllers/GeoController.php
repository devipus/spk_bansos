<?php

namespace App\Http\Controllers;
use App\Cities;
use App\Countries;
use App\Districts;
use App\Regions;
use App\Villages;

use Illuminate\Http\Request;

class GeoController extends Controller
{
    public function region(Request $request){
    	if(!$request->ajax()){
    		abort(404,'Not Found');
    	}
    	$query= Regions::select('code as id', 'code', 'country', 'name')->where('country','=','ID');
    	if(isset($request['code'])&&$request['code']!=''){

    		$query->where('code', $request['code']);
    	}
        if(isset($request['q'])&&$request['q']!=''){

            $query->where('name','like','%'. $request['q'].'%');
        }

    	$querys=$query->get()->toArray();
    	 return response()->json($querys);
    }
    public function cities(Request $request){
    	if(!$request->ajax()){
    		abort(404,'Not Found');
    	}
    	$query= Cities::select('code as id', 'code','region', 'country', 'name')->where('country','=','ID');
    	if(isset($request['code'])&&$request['code']!=''){

    		$query->where('code', $request['code']);
    	}
    	if(isset($request['region'])&&$request['region']!=''){

    		$query->where('region', $request['region']);
    	}
         if(isset($request['q'])&&$request['q']!=''){

            $query->where('name','like','%'. $request['q'].'%');
        }
    	$querys=$query->get()->toArray();
    	 return response()->json($querys);
    }
    public function districts(Request $request){
	if(!$request->ajax()){
    		abort(404,'Not Found');
    	}
    	$query= Districts::select('code as id', 'code','region', 'city', 'country', 'name')->where('country','=','ID');
    	if(isset($request['code'])&&$request['code']!=''){

    		$query->where('code', $request['code']);
    	}
    	if(isset($request['region'])&&$request['region']!=''){

    		$query->where('region', $request['region']);
    	}
    	if(isset($request['city'])&&$request['city']!=''){

    		$query->where('city', $request['city']);
    	}
         if(isset($request['q'])&&$request['q']!=''){

            $query->where('name','like','%'. $request['q'].'%');
        }
    	$querys=$query->get()->toArray();
    	 return response()->json($querys);
    }
    public function villages(Request $request){
    	if(!$request->ajax()){
    		abort(404,'Not Found');
    	}
    	$query= Villages::select('code as id', 'code','region', 'city', 'district', 'country', 'name')->where('country','=','ID');
    	if(isset($request['code'])&&$request['code']!=''){

    		$query->where('code', $request['code']);
    	}
    	if(isset($request['region'])&&$request['region']!=''){

    		$query->where('region', $request['region']);
    	}
    	if(isset($request['city'])&&$request['city']!=''){

    		$query->where('city', $request['city']);
    	}
    	if(isset($request['district'])&&$request['district']!=''){

    		$query->where('district', $request['district']);
    	}

         //untuk pencarian
        if(isset($request['q'])&&$request['q']!=''){

            $query->where('name','like','%'. $request['q'].'%');
        }
    	$querys=$query->get()->toArray();
    	 return response()->json($querys);
    }
   
}
