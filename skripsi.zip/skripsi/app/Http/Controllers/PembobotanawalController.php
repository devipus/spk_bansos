<?php
/**['id_pembobotanawal', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_pangkat', 'ket_dos', 'rutinitas'];*/

namespace App\Http\Controllers;

use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;

use App\Pembobotanawal;

use Validator;
use App\Http\Requests\PembobotanawalRequest;
use Illuminate\Support\Facades\DB;


class PembobotanawalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
           return view('pembobotanawal');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PembobotanawalRequest $request)
    
        /**['id_pembobotanawal', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_pangkat', 'ket_dos', 'rutinitas'];*/
      {
        


        $data = [
        'kriteria_1a' => $request['kriteria_1a'],
        'kriteria_1b' => $request['kriteria_1b'],
        'kriteria_1c' => $request['kriteria_1c'],
        'kriteria_2a' => $request['kriteria_2a'],
        'kriteria_2b' => $request['kriteria_2b'],
        'kriteria_3a' => $request['kriteria_3a'],
        'kriteria_3b' => $request['kriteria_3b'],
        'kriteria_4a' => $request['kriteria_4a'],
        'kriteria_4b' => $request['kriteria_4b'],
        'kriteria_4c' => $request['kriteria_4c'],
        'kriteria_4d' => $request['kriteria_4d'],
        'kriteria_4e' => $request['kriteria_4e'],
        'kriteria_5a' => $request['kriteria_5a'],
        'kriteria_5b' => $request['kriteria_5b'],
        'kriteria_6a' => $request['kriteria_6a'],
        'kriteria_6b' => $request['kriteria_6b'],
    'kriteria_6c' => $request['kriteria_6c'],
        'kriteria_7a' => $request['kriteria_7a'],
        'kriteria_7b' => $request['kriteria_7b']
      
   
        ];

       return Pembobotanawal::create($data);
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $pembobotanawal = Pembobotanawal::find($id);
        return $pembobotanawal;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        // $pembobotanawal = Pembobotanawal::find($id);
        //     $pembobotanawal->kriteria_1a =$request['kriteria_1a'];
        //     $pembobotanawal->kriteria_1b =$request['kriteria_1b'];
        //     $pembobotanawal->kriteria_1c =$request['kriteria_1c']; 

        //     $pembobotanawal->kriteria_2a =$request['kriteria_2a'];
        //     $pembobotanawal->kriteria_2b =$request['kriteria_2b'];
        //     $pembobotanawal->kriteria_3a =$request['kriteria_3a'];
        //     $pembobotanawal->kriteria_3b =$request['kriteria_3b'];
        //     $pembobotanawal->kriteria_4a =$request['kriteria_4a'];
        //     $pembobotanawal->kriteria_4b =$request['kriteria_4b'];
        //     $pembobotanawal->kriteria_4c =$request['kriteria_4c'];
        //     $pembobotanawal->kriteria_4d =$request['kriteria_4d'];
        //     $pembobotanawal->kriteria_4e =$request['kriteria_4e'];
        //     $pembobotanawal->kriteria_5a =$request['kriteria_5a'];
        //     $pembobotanawal->kriteria_5b =$request['kriteria_5b'];
        //     $pembobotanawal->kriteria_6a =$request['kriteria_6a'];
        //     $pembobotanawal->kriteria_6b =$request['kriteria_6b'];
        //     $pembobotanawal->kriteria_7a =$request['kriteria_7a'];
        //     $pembobotanawal->kriteria_7b =$request['kriteria_7b'];

          
        // $pembobotanawal->update();
        // return $pembobotanawal;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
   {
    if($pembobotanawalDel = Pembobotanawal::destroy($id)){
            return ['success' =>  1];
        }else{
            return ['tidak success' =>  0];
        }
    }
     public function  apiPembobotanawal()
    {

//$user=\Auth::user();
          // $pembobotanawal = pembobotanawal::find($user->id);

    // $pembobotanawal = Pembobotanawal::all();
       //$pembobotanawal= siswa::where('id','=',$id)->first();

  $pembobotanawal = pembobotanawal::all();
      ///  $pembobotanawal = pembobotanawal::select('tanggal',DB::raw("(SUM(ns_siang)) as ns_siang"),DB::raw("(SUM(tkno_siang)) as tkno_siang"),DB::raw("(SUM(tamu_siang)) as tamu_siang"),DB::raw("(SUM(ss_malam)) as ss_malam"),DB::raw("(SUM(ns_malam)) as ns_malam"))->groupBy('tanggal')->get(); //pertanggal,
        return DataTables::of($pembobotanawal)
            ->addColumn('action', function($pembobotanawal) {
                return  
                        '<a onclick="editForm('. $pembobotanawal->id_pembobotanawal .')" class=btn btn-primary btn-xs"> <i class="glyphicon glyphicon-edit"> </i> Edit </a>' .
                        
                        '<a onclick="deleteData('. $pembobotanawal->id_pembobotanawal .')" class=btn btn-danger btn-xs"> <i class="glyphicon glyphicon-trash"> </i> Delete </a>' ;

            })->make(true);
    }

    
}
