<?php
/**['id_Kabkota', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Kabkota', 'ket_dos', 'rutinitas'];*/

namespace App\Http\Controllers;

use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;

use App\Kabkota;

use Validator;
use routes;
use App\Http\Requests\KabkotaRequest;
use Illuminate\Support\Facades\DB;


class KabkotaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
           return view('kabkota');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(KabkotaRequest $request)
    
        /**['id_Kabkota', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Kabkota', 'ket_dos', 'rutinitas'];*/
      {
        
        $data = [
        'kabkota' => $request['kabkota'],
       
   
        ];

       return Kabkota::create($data);
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $Kabkota = Kabkota::find($id);
        return $Kabkota;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $Kabkota = Kabkota::find($id);
            $Kabkota->kabkota =$request['kabkota'];
          
        $Kabkota->update();
        return $Kabkota;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
   {
    if($KabkotaDel = Kabkota::destroy($id)){
            return ['success' =>  1];
        }else{
            return ['tidak success' =>  0];
        }
    }
     public function  apiKabkota()
    {

//$user=\Auth::user();
          // $Kabkota = Kabkota::find($user->id);

     $Kabkota = Kabkota::all();
       //$Kabkota= siswa::where('id','=',$id)->first();
  // $Kabkota = Kabkota::where('user_id','=',\Auth::user()->id)->with('kegiatan')->get();
      ///  $Kabkota = Kabkota::select('tanggal',DB::raw("(SUM(ns_siang)) as ns_siang"),DB::raw("(SUM(tkno_siang)) as tkno_siang"),DB::raw("(SUM(tamu_siang)) as tamu_siang"),DB::raw("(SUM(ss_malam)) as ss_malam"),DB::raw("(SUM(ns_malam)) as ns_malam"))->groupBy('tanggal')->get(); //pertanggal,
        return DataTables::of($Kabkota)
            ->addColumn('action', function($Kabkota) {
                return  
                        '<a onclick="editForm('. $Kabkota->id_kabkota .')" class=btn btn-primary btn-xs"> <i class="glyphicon glyphicon-edit"> </i> Edit </a>' .
                        
                        '<a onclick="deleteData('. $Kabkota->id_kabkota .')" class=btn btn-danger btn-xs"> <i class="glyphicon glyphicon-trash"> </i> Delete </a>' ;

            })->make(true);
    }

    
}
