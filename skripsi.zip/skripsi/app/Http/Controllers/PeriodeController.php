<?php
/**['id_Periode', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Periode', 'ket_dos', 'rutinitas'];*/

namespace App\Http\Controllers;

use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;

use App\Periode;

use Validator;
use routes;
use App\Http\Requests\PeriodeRequest;
use Illuminate\Support\Facades\DB;


class PeriodeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
           return view('periode');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PeriodeRequest $request)
    
        /**['id_Periode', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Periode', 'ket_dos', 'rutinitas'];*/
      {
        
        $data = [
        'periode' => $request['periode'],
       
   
        ];

       return Periode::create($data);
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $Periode = Periode::find($id);
        return $Periode;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $Periode = Periode::find($id);
            $Periode->periode =$request['periode'];
          
        $Periode->update();
        return $Periode;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
   {
    if($PeriodeDel = Periode::destroy($id)){
            return ['success' =>  1];
        }else{
            return ['tidak success' =>  0];
        }
    }
     public function  apiPeriode()
    {

//$user=\Auth::user();
          // $Periode = Periode::find($user->id);

     $Periode = Periode::all();
       //$Periode= siswa::where('id','=',$id)->first();
  // $Periode = Periode::where('user_id','=',\Auth::user()->id)->with('kegiatan')->get();
      ///  $Periode = Periode::select('tanggal',DB::raw("(SUM(ns_siang)) as ns_siang"),DB::raw("(SUM(tkno_siang)) as tkno_siang"),DB::raw("(SUM(tamu_siang)) as tamu_siang"),DB::raw("(SUM(ss_malam)) as ss_malam"),DB::raw("(SUM(ns_malam)) as ns_malam"))->groupBy('tanggal')->get(); //pertanggal,
        return DataTables::of($Periode)
            ->addColumn('action', function($Periode) {
                return  
                        '<a onclick="editForm('. $Periode->id_periode .')" class=btn btn-primary btn-xs"> <i class="glyphicon glyphicon-edit"> </i> Edit </a>' .
                        
                        '<a onclick="deleteData('. $Periode->id_periode .')" class=btn btn-danger btn-xs"> <i class="glyphicon glyphicon-trash"> </i> Delete </a>' ;

            })->make(true);
    }

    
}
