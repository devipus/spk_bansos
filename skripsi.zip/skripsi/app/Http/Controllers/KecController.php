<?php
/**['id_Kec', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Kec', 'ket_dos', 'rutinitas'];*/

namespace App\Http\Controllers;

use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;

use App\Kec;

use Validator;
use routes;
use App\Http\Requests\KecRequest;
use Illuminate\Support\Facades\DB;


class KecController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
           return view('kec');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(KecRequest $request)
    
        /**['id_Kec', 'nama', 'alamat', 'hp', 'id-gol', 'status', 'id_Kec', 'ket_dos', 'rutinitas'];*/
      {
        
        $data = [
        'kec' => $request['kec'],
       
   
        ];

       return Kec::create($data);
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $Kec = Kec::find($id);
        return $Kec;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $Kec = Kec::find($id);
            $Kec->kec =$request['kec'];
          
        $Kec->update();
        return $Kec;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
   {
    if($KecDel = Kec::destroy($id)){
            return ['success' =>  1];
        }else{
            return ['tidak success' =>  0];
        }
    }
     public function  apiKec()
    {

//$user=\Auth::user();
          // $Kec = Kec::find($user->id);

     $Kec = Kec::all();
       //$Kec= siswa::where('id','=',$id)->first();
  // $Kec = Kec::where('user_id','=',\Auth::user()->id)->with('kegiatan')->get();
      ///  $Kec = Kec::select('tanggal',DB::raw("(SUM(ns_siang)) as ns_siang"),DB::raw("(SUM(tkno_siang)) as tkno_siang"),DB::raw("(SUM(tamu_siang)) as tamu_siang"),DB::raw("(SUM(ss_malam)) as ss_malam"),DB::raw("(SUM(ns_malam)) as ns_malam"))->groupBy('tanggal')->get(); //pertanggal,
        return DataTables::of($Kec)
            ->addColumn('action', function($Kec) {
                return  
                        '<a onclick="editForm('. $Kec->id_kec .')" class=btn btn-primary btn-xs"> <i class="glyphicon glyphicon-edit"> </i> Edit </a>' .
                        
                        '<a onclick="deleteData('. $Kec->id_kec .')" class=btn btn-danger btn-xs"> <i class="glyphicon glyphicon-trash"> </i> Delete </a>' ;

            })->make(true);
    }

    
}
