<?php namespace App\Http\Requests;

class KecRequest extends Request {
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
    

        return [



        'kec' => 'max:40|required',
        
      
        
            
        ];

    }
   public function validateBatasan()
   {

   }
}
