<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AlternatifRequest extends Request
{
    

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
             'alternatif' => 'max:20|required',
             'budget' => 'max:20|required',
             'dp' => 'max:20|required',
             'lokasi' => 'max:20|required',
             'harga' => 'max:20|required',
             'bonus' => 'max:20|required',
        
        ];
    }
}
