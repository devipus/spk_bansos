<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PembobotanawalRequest extends Request
{

           

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
            return [
             'kriteria_1a' => 'max:40|required',
              'kriteria_1b' => 'max:40|required',
             'kriteria_1c' => 'max:40|required',
             'kriteria_2a' => 'max:40|required',
             'kriteria_2b' => 'max:40|required',
             'kriteria_3a' => 'max:40|required',
             'kriteria_3b' => 'max:40|required',
             'kriteria_4a' => 'max:40|required',
             'kriteria_4b' => 'max:40|required',
             'kriteria_4c' => 'max:40|required',
             'kriteria_4d' => 'max:40|required',
             'kriteria_4e' => 'max:40|required',
             'kriteria_5a' => 'max:40|required',
             'kriteria_5b' => 'max:40|required',
             'kriteria_6a' => 'max:40|required',
             'kriteria_6b' => 'max:40|required',
             'kriteria_6c' => 'max:40|required',
             'kriteria_7a' => 'max:40|required',
             'kriteria_7b' => 'max:40|required',
        ];
    }
}