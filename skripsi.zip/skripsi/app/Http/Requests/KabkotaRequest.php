<?php namespace App\Http\Requests;

class KabkotaRequest extends Request {
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
    

        return [



        'kabkota' => 'max:40|required',
        
      
        
            
        ];

    }
   public function validateBatasan()
   {

   }
}
