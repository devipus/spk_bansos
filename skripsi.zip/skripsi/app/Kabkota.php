<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kabkota extends Model
{
     Protected $primaryKey ='id_kabkota';
   Protected $fillable=['id_kabkota','kabkota'];
}
