<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kec extends Model
{
    Protected $primaryKey ='id_kec';
   Protected $fillable=['id_kec','kec'];
}
