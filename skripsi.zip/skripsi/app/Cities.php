<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cities extends Model
{
     Protected $primaryKey ='id';
   Protected $fillable=['id','country','region','code','name','latitude','longitude'];
    Protected $table ='geo_cities';
    public function countrys(){
   		 return $this -> hasOne (Countries::class, 'iso', 'country');

   }
   public function regions(){
   		 return $this -> hasOne (Regions::class, 'code', 'region');
   }
   public function districts(){
   		 return $this -> hasOne (Districts::class, 'city', 'code');
   }
   public function villages(){
   		 return $this -> hasOne (Villages::class, 'city', 'code');
   }
}
