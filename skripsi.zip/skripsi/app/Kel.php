<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kel extends Model
{
    Protected $primaryKey ='id_kel';
   Protected $fillable=['id_kel','kel'];
}
